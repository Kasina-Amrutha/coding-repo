using Microsoft.AspNetCore.Identity;

namespace SecureTaskManager.Models
{
    public class ApplicationUser : IdentityUser
    {
        
    }
}
